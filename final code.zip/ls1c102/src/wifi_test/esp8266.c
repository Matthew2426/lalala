#include "esp8266.h"
#include "Config.h"
#include "ls1x_string.h"
#include "ls1x_printf.h"
#include "ls1x_latimer.h"
#include "ls1x_gpio.h"

#include "queue.h"

//#include "cJSON.h"



uint8_t Read_Buffer[DATA_LEN];//设置接收缓冲数组
uint8_t Read_length;
/*
    在进行esp8266试验过程中prinf对应于上位机发送
                           myprintf2(0,#fmt,..)用于发送
*/


// ESP8266 发送命令后，检测接收到的应答
// str：期待的应答结果
// 返回值：0，没有得到期待的应答结果；其他，期待应答结果的位置(str的位置)
char* esp8266_check_cmd(char *str)//
{
    char *strx = NULL;

    if(Queue_isEmpty(&Circular_queue)==0)//判断队列是否为空，即判断是否收到数据
    {
        Read_length=Queue_HadUse(&Circular_queue);//返回队列中数据的长度
        {
            memset(Read_Buffer, 0, DATA_LEN);//填充接收缓冲区为0
            Queue_Read(&Circular_queue, Read_Buffer,Read_length);//读取队列缓冲区的值到接收缓冲区
            Read_Buffer[Read_length]='\0';//字符串接收结束符
            printf("check UART0_RX_BUF:%s\r\n", Read_Buffer);// 打印正确
        }

    }

    strx = pstrstr((const char*)Read_Buffer, (const char*)str);
    return strx;
}

// 向 ESP8266 发送命令
// cmd：发送的命令字符串。
// ack：期待的应答结果，如果为空，则表示不需要等待应答
// waittime：等待时间
// 返回值：0，发送成功(得到了期待的应答结果)；1，发送失败
char esp8266_send_cmd(char *cmd, char *ack, uint16_t waittime)
{
    char res = 0;
    //UART0_RX_STA = 0;
    printf("cmd:%s\r\n", cmd);
   
    myprintf2(0,"%s\r\n", cmd);	//发送命令
    if(ack && waittime)		//需要等待应答
    {
         //printf("check UART0_RX_BUF:%s\r\n", Read_Buffer);// 打印正确
        while(--waittime)	//等待倒计时
        {

            delay_ms(1000);
            //printf("等待倒计时\r\n");

            if(esp8266_check_cmd(ack))
            {
                printf("ack:%s\r\n", ack);
                break;//得到有效数据
            }

        }
        if(waittime == 0)
        {
            res = 1;
        }
        else printf("res:%d\r\n", res);
    }
    return res;
}


void esp8266_init(void)
{
    // 设置工作模式 1：station模式   2：AP模式   3：兼容 AP+station模式
    printf("AT+CWMODE=1\r\n");
    while(esp8266_send_cmd("AT+CWMODE=1", "OK", 300));

    delay_ms(500);
    // 让 WIFI 模块重启
    // printf("AT+RST\r\n");
    // while(esp8266_send_cmd("AT+RST", "OK", 300));
    // 让模块连接上自己的手机热点
    // printf("AT+CWJAP=LALALA,4001234567\r\n");
    // while(esp8266_send_cmd("AT+CWJAP=\"LALALA\",\"4001234567\"","OK", 300));
    // =0：单路连接模式；=1：多路连接模式
    // printf("AT+CIPMUX=0\r\n");
    // while(esp8266_send_cmd("AT+CIPMUX=0","OK",150));
    // 建立TCP连接  这三项分别代表：连接类型、远程服务器IP地址、远程服务器端口号
    // printf("AT+CIPSTART=TCP,mqtts.heclouds.com,1883\r\n");
    // while(esp8266_send_cmd("AT+CIPSTART=\"TCP\",\"mqtts.heclouds.com\",1883","OK",300));
    
    //断开连接
    // printf("AT+MQTTCLEAN=0\r\n");
    // while(esp8266_send_cmd("AT+MQTTCLEAN=0","OK",300));
    //设置station模式，开启DHCP
    // printf("AT+CWDHCP=1,1\r\n");
    // while(esp8266_send_cmd("AT+CWDHCP=1,1","OK",300));
    //定义设备名
    printf("AT+MQTTUSERCFG=0,1,\"test\",\"5ZAt7uj9BY\",\"version=2018-10-31&res=products%2F5ZAt7uj9BY%2Fdevices%2Ftest&et=1722862500&method=md5&sign=7%2B75ylSTzITssVTIjh4BuQ%3D%3D\",0,0,\"\"\r\n");
    while(esp8266_send_cmd("AT+MQTTUSERCFG=0,1,\"test\",\"5ZAt7uj9BY\",\"version=2018-10-31&res=products%2F5ZAt7uj9BY%2Fdevices%2Ftest&et=1722862500&method=md5&sign=7%2B75ylSTzITssVTIjh4BuQ%3D%3D\",0,0,\"\"","OK",300));
    
    //连接onenet云平台
    printf("AT+MQTTCONN=0,\"mqtts.heclouds.com\",1883,1\r\n");
    while(esp8266_send_cmd("AT+MQTTCONN=0,\"mqtts.heclouds.com\",1883,1","OK",300));//token长导致响应时间慢
    
    //订阅onenet云平台
    printf("AT+MQTTSUB=0,\"$sys/5ZAt7uj9BY/test/thing/property/set\",1\r\n");
    while(esp8266_send_cmd("AT+MQTTSUB=0,\"$sys/5ZAt7uj9BY/test/thing/property/set\",1","OK",300));

    //上报电源关闭
    printf("AT+MQTTPUB=0,\"$sys/5ZAt7uj9BY/test/thing/property/post\",\"{\\\"id\\\":\\\"123\\\"\\,\\\"params\\\":{\\\"power\\\":{\\\"value\\\":false}}}\",0,0\r\n");
    while(esp8266_send_cmd("AT+MQTTPUB=0,\"$sys/5ZAt7uj9BY/test/thing/property/post\",\"{\\\"id\\\":\\\"123\\\"\\,\\\"params\\\":{\\\"power\\\":{\\\"value\\\":false}}}\",0,0","OK",300));

    printf("esp8266_init_finish\r\n");
    
    // 是否开启透传模式，=0：表示关闭透传；=1：表示开启透传
    // printf("AT+CIPMODE=1\r\n");
    // esp8266_send_cmd("AT+CIPMODE=1", "OK", 150);

    // 透传模式下开始发送数据的指令，这个指令之后就可以直接发数据了
    // printf("AT+CIPSEND\r\n");
    // esp8266_send_cmd("AT+CIPSEND", "OK", 150);
}

// 向 ESP8266 发送数据
// cmd：发送的命令字符串
// waittime：等待时间
// 返回值：发送数据后，服务器的返回验证码
void esp8266_send_data(char *cmd)
{
    myprintf2(0,"%s",cmd);// 发送数据
}

//向onenet云平台上报电源开启
void esp8266_set_power_on(void)
{
    printf("AT+MQTTPUB=0,\"$sys/5ZAt7uj9BY/test/thing/property/post\",\"{\\\"id\\\":\\\"123\\\"\\,\\\"params\\\":{\\\"power\\\":{\\\"value\\\":true}}}\",0,0\r\n");
    while(esp8266_send_cmd("AT+MQTTPUB=0,\"$sys/5ZAt7uj9BY/test/thing/property/post\",\"{\\\"id\\\":\\\"123\\\"\\,\\\"params\\\":{\\\"power\\\":{\\\"value\\\":true}}}\",0,0","OK",300));
    printf("AT+MQTTPUB=0,\"$sys/5ZAt7uj9BY/test/thing/property/post\",\"{\\\"id\\\":\\\"123\\\"\\,\\\"params\\\":{\\\"power_state\\\":{\\\"value\\\":1}}}\",0,0\r\n");
    while(esp8266_send_cmd("AT+MQTTPUB=0,\"$sys/5ZAt7uj9BY/test/thing/property/post\",\"{\\\"id\\\":\\\"123\\\"\\,\\\"params\\\":{\\\"power_state\\\":{\\\"value\\\":1}}}\",0,0","OK",300));
}

//向onenet云平台上报电源关闭
void esp8266_set_power_off(void)
{
    printf("AT+MQTTPUB=0,\"$sys/5ZAt7uj9BY/test/thing/property/post\",\"{\\\"id\\\":\\\"123\\\"\\,\\\"params\\\":{\\\"power\\\":{\\\"value\\\":false}}}\",0,0\r\n");
    while(esp8266_send_cmd("AT+MQTTPUB=0,\"$sys/5ZAt7uj9BY/test/thing/property/post\",\"{\\\"id\\\":\\\"123\\\"\\,\\\"params\\\":{\\\"power\\\":{\\\"value\\\":false}}}\",0,0","OK",300));
    printf("AT+MQTTPUB=0,\"$sys/5ZAt7uj9BY/test/thing/property/post\",\"{\\\"id\\\":\\\"123\\\"\\,\\\"params\\\":{\\\"power_state\\\":{\\\"value\\\":0}}}\",0,0\r\n");
    while(esp8266_send_cmd("AT+MQTTPUB=0,\"$sys/5ZAt7uj9BY/test/thing/property/post\",\"{\\\"id\\\":\\\"123\\\"\\,\\\"params\\\":{\\\"power_state\\\":{\\\"value\\\":0}}}\",0,0","OK",300));
}

// cJSON *raw_json, *params_json, *power_json;
// char *req_payload = NULL;

// //数据解包
// raw_json = cJSON_Parse(req_payload);
// params_json = cJSON_GetObjectItem(raw_json,"params");
// power_json = cJSON_GetObjectItem(params_json,"power");

// if(power_json->type == cJSON_True)
// {
//     gpio_write_pin(GPIO_PIN_1,1);
//     printf("power on\r\n");
// }
// else 
// {
//     gpio_write_pin(GPIO_PIN_1,0);
//     printf("power off\r\n");
// }

// cJSON_Delete(raw_json);
