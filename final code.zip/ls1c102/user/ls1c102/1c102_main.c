
#include "ls1x.h"
#include "Config.h"
#include "ls1x_gpio.h"
#include "ls1x_latimer.h"
#include "esp8266.h"
#include "ls1c102_interrupt.h"
#include "ls1x_printf.h"
#include "key.h"

uint8_t key_index[16]= {0x11, 0x12, 0x14, 0x18, 0x21, 0x22, 0x24, 0x28, 0x41, 0x42, 0x44, 0x48, 0x81, 0x82, 0x84, 0x88};

uint8_t key_table[16]= {'1','2','3','A','4','5','6','B','7','8','9','C','*','0','#','D'};

int main(int arg, char *args[])
{
    // gpio_pin_remap(GPIO_PIN_6, 1);
    // gpio_pin_remap(GPIO_PIN_7, 1);
    //console0_init(115200);
    //printf("uart0_init_finish");



    esp8266_init();

    printf("main begin\r\n");
    
    uint8_t key_value;
    int pw_cnt=0; 

    gpio_write_pin(GPIO_PIN_20, 1);

    for (;;)
    {       
        key_value = key_scan();
        if(key_value != 0)
        {
            printf("key_value:%x\r\n", key_value);
            for(int i = 0; i < 16; i++)
            {
                if(key_value == key_index[i])
                {
                    printf("key:%c\r\n", key_table[i]);
                    
                    if(key_value == key_index[0])//第一位密码
                    {
                        pw_cnt = 1;
                        
                    }
                    else if(pw_cnt==1)
                    {
                        if(key_value == key_index[1])//第二位密码
                        {
                            pw_cnt = 2;
                        }
                        
                    }
                    else if(pw_cnt == 2)
                    {
                        if(key_value == key_index[2])//第三位密码
                        {
                            pw_cnt = 3;
                        }
                    }
                    else if(pw_cnt == 3)
                    {
                        if(key_value == key_index[15])//确认键“D”
                        {
                        printf("password correct\n");
                        esp8266_set_power_on();
                        gpio_write_pin(GPIO_PIN_1, 1);
                        pw_cnt = 0;
                        }
                    }
                    if(key_value == key_index[12])//关机键“*”
                    {
                        printf("power off\n");
                        esp8266_set_power_off();
                        gpio_write_pin(GPIO_PIN_1, 0);
                    }

                }
            }
        }
        
        delay_ms(300);
    }

    return 0;
}
